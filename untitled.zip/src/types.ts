export interface TranslationDict {
  navHome: string;
  navEducation: string;
  navProjects: string;
  navSkills: string;
  navLearning: string;
  navContact: string;

  heroTitle: string;
  heroSub: string;
  heroBio: string;
  heroMotto: string;
  btnResume: string;
  btnContact: string;
  btnMatch: string;
  btnCopyPhone: string;
  btnCopied: string;

  eduTitle: string;
  eduSchool: string;
  eduDegree: string;
  eduPeriod: string;
  eduDirection: string;
  eduDescription: string;
  eduAward: string;
  eduAwardName: string;

  projTitle: string;
  projRole: string;
  projDuties: string;
  projViewDetail: string;
  projCollapseDetail: string;

  proj1Title: string;
  proj1Sub: string;
  proj1Desc: string;
  proj1Details: string[];
  proj1Insights: string[];

  proj2Title: string;
  proj2Sub: string;
  proj2Desc: string;
  proj2Details: string[];
  proj2Insights: string[];

  proj3Title: string;
  proj3Sub: string;
  proj3Desc: string;
  proj3Details: string[];
  proj3Insights: string[];

  skillsTitle: string;
  skillsResearch: string;
  skillsProduct: string;
  skillsDesign: string;
  skillsAi: string;

  learnTitle: string;
  learnDesc: string;
  learnItems: {
    title: string;
    desc: string;
    tag: string;
  }[];

  matcherTitle: string;
  matcherSub: string;
  matcherPlaceholder: string;
  matcherBtn: string;
  matcherDemoBtn: string;
  matcherScanning: string[];
  matcherResultTitle: string;
  matcherScore: string;
  matcherLevel: string;
  matcherHighlights: string;
  matcherImprovements: string;
  matcherSummary: string;
  matcherRoles: string;
  matcherClose: string;

  contactTitle: string;
  contactSubtitle: string;
  contactPhone: string;
  contactEmail: string;
  contactStatus: string;
  contactBackToTop: string;
}

export const cnTranslations: TranslationDict = {
  navHome: "关于我",
  navEducation: "教育背景",
  navProjects: "项目经历",
  navSkills: "技能特长",
  navLearning: "学习与探索",
  navContact: "联系我",

  heroTitle: "Hi，我是潘碧莹",
  heroSub: "工业设计工程硕士 / 服务体验设计研究者",
  heroBio: "我目前是广东工业大学工业设计工程专业的研究生，研究方向聚焦于服务体验设计与用户研究。我具备深厚的工科硕士学术素养和敏锐的用户洞察力，擅长在复杂场景中拆解用户痛点、提炼行为数据并构建落地化的产品与服务系统。在AI时代，我积极探索并倡导AI驱动的创新设计流，致力于成为兼具研究力、共情心与技术视野的优秀产品经理与用户研究员。",
  heroMotto: "努力生活，也努力把问题看清楚。",
  btnResume: "下载简历 (PDF)",
  btnContact: "与我联系",
  btnMatch: "AI 岗位匹配器",
  btnCopyPhone: "复制联系电话",
  btnCopied: "已复制到剪贴板",

  eduTitle: "教育背景 / Education",
  eduSchool: "广东工业大学 (Guangdong University of Technology)",
  eduDegree: "硕士研究生 (工科硕士)",
  eduPeriod: "2025.09 – 2028.06 (在读)",
  eduDirection: "研究方向：服务体验设计、用户体验研究、系统化产品策划",
  eduDescription: "在校期间深入研修用户洞察、跨学科设计研究方法、人机交互体验与数字服务设计。在课程和实验室科研任务中，建立了一套严谨的、从痛点发现到落地转化的工科系统化设计思维框架，能够熟练地将学术方法应用于商业应用开发。",
  eduAward: "荣誉奖项",
  eduAwardName: "华灿奖全国一等奖 (National First Prize, Huacan Award)",

  projTitle: "项目经历 / Projects",
  projRole: "担任职责",
  projDuties: "核心工作内容",
  projViewDetail: "查看详情 & 过程产出",
  projCollapseDetail: "收起详情",

  proj1Title: "小米电视桌面系统设计白皮书",
  proj1Sub: "用户行为分析 / 交互框架设计 / 桌面大屏系统体验",
  proj1Desc: "该项目聚焦智能电视大屏桌面系统的用户行为与痛点研究。通过大量的实地访谈、眼动实验和点击数据流分析，重点解构了用户在家庭多光源、远距离视听场景下的“信息检索路径”、“内容浏览偏好”与“核心操作决策”，为下一代电视大屏桌面交互提供严谨的用户行为和设计规范支撑。",
  proj1Details: [
    "「用户行为矩阵重构」：绘制了超过5类典型家庭角色的电视桌面使用动线，发现用户在信息流深度超过3层时流失率增加 42%。",
    "「信息架构精简」：重构导航架构，压缩桌面视觉层级，提出多维联动式推荐交互逻辑，让用户单次内容获取路径缩短 35%。",
    "「动态布局规范」：根据大屏远视距特征（2.5m - 3.5m），协助团队提炼了不同卡片大小与视觉焦点的极简排布原则。"
  ],
  proj1Insights: [
    "电视桌面系统不仅是内容呈现媒介，更是家庭多成员共用场景下的情感交织点，交互设计必须极简、零等待。",
    "将复杂的用户行为数据，提炼为具体卡片的动态排布原则，是用户研究员核心的桥梁价值。"
  ],

  proj2Title: "粤港澳大湾区“缮居”适老化公益改造设计",
  proj2Sub: "广东省工业设计协会公益项目 / 适老化空间研究 / 动线重组与评估报告",
  proj2Desc: "参与广东省工业设计协会主导的大湾区适老化空间帮扶项目。深入顺德2户特殊帮扶家庭进行多轮实地调研、空间扫描、行为轨迹测绘。结合老年人身体机能退化特征、日常起居和护理痛点，运用服务设计链路、用户画像、体验旅程图等方法，输出兼具空间适老安全与心理关怀的整套评估报告与空间优化蓝图，极高地提升了帮扶家庭的晚年生活品质。",
  proj2Details: [
    "「实地参与式观察」：累计进行超过 40 小时的田野调查与居家深度访谈，精准定位老年人在卫生间湿滑跌倒、卧室起床扶手空缺、厨房收纳高频弯腰等 12 处高危物理隐患点。",
    "「适老化动线重组」：应用行为流测绘，重组老人清晨起床-洗漱-早餐的最短安全交互动线，减少非必要曲折路径，避免二次跌倒伤害。",
    "「评估与改造方案输出」：主导撰写共计 80 页的「缮居实地微改造评估报告与蓝图」，输出包括低成本多功能扶手布局、折叠淋浴凳、无障碍光环境等在内的实用改造策略，获得了行业协会和社区的高度认可。"
  ],
  proj2Insights: [
    "适老化设计绝对不是简单的安装扶手，而是对老年人全天生活方式、感官衰退细节与自尊心理的深度体恤。",
    "好的设计必须有温度，工科硕士的逻辑力能让温度真正落地。"
  ],

  proj3Title: "AI协同原型与设计研究开发",
  proj3Sub: "AI 与代码协同 / 全栈响应式开发 / 个人作品集快速搭建与部署",
  proj3Desc: "在人工智能驱动变革的背景下，积极探索将大语言模型（LLM）与前端开发代码深度结合。通过手写 HTML/JS/React 与 Tailwind CSS，不依赖传统臃肿的研发流程，实现从“用研洞察 - 交互原型 - 响应式代码 - 自动化云部署”的全链路闭环验证，极高地拓宽了产品经理的工程视野与创新实现边界。本个人作品集网站正是该研究的标杆产出。",
  proj3Details: [
    "「AI 提示词工程闭环」：构建了面向用研文本提炼、产品 PRD 结构化生成的多套 System Prompts，使用大模型对非结构化反馈进行聚类，需求整理提效 300%。",
    "「响应式前端独立开发」：手写并优化本作品集的 React + Tailwind 架构，实现极其流畅的微交互、完美的移动端自适应以及高性能渲染。",
    "「全栈式匹配算法设计」：在 Express 骨架上实现了双引擎岗位匹配诊断机制（Gemini AI 语义解析与关键词过滤），为招聘方提供一键式、极具说服力的互动评估体验。"
  ],
  proj3Insights: [
    "在 AI 时代，产品经理不应只停留在画线框图，而是要用 AI 作为杠杆，掌握手写响应式原型的全栈交付能力，让好点子当天就能上线运行。",
    "AI 与代码的协同，极大地缩短了用户研究到原型测试的反馈环，是新一代复合型数字化产品经理的终极壁垒。"
  ],

  skillsTitle: "技能特长 / Skills",
  skillsResearch: "用户研究能力 (User Research)",
  skillsProduct: "产品与服务设计 (Product & Service)",
  skillsDesign: "设计工具 (Design Tools)",
  skillsAi: "AI 与代码协同 (AI & Code Collaboration)",

  learnTitle: "学习与探索 / Learning & Exploration",
  learnDesc: "作为一名新一代的数字化产品经理与用户研究员，我深信 AI 不仅仅是效率工具，更是一种帮助设计师和研究员快速验证想法、拓展表达边界、搭建轻量级产品模型的新型「协作伙伴」。我致力于探索「研究-设计-AI辅助原型-代码落地」的全栈链路。",
  learnItems: [
    {
      title: "AI 辅助用户需求分析 & 信息提炼",
      desc: "利用 ChatGPT 等大语言模型建立结构化 Prompt 模板，辅助处理高密度的定性访谈文本。对数万字的用户访谈录音进行语义聚类，提取出核心痛点，使传统质性分析效率提升 3 倍以上，确保洞察有据可依。",
      tag: "ChatGPT"
    },
    {
      title: "AI 辅助视觉概念与情境渲染生成",
      desc: "在项目初期创意发散阶段，使用 Midjourney、Stable Diffusion 快速合成用户体验场景图、情绪板与适老化改造意向图。能够用精确的提示词将枯燥的概念方案转化为富有情感张力的视觉参考，让利益相关者一眼看清未来图景。",
      tag: "Midjourney"
    },
    {
      title: "AI 辅助网页原型搭建 & 动效开发",
      desc: "打破设计师与开发者的界限，利用 OpenCode 平台与大模型辅助，手写 HTML、Tailwind CSS 及 JavaScript，实现网页端作品集与交互原型的快速交付。本站即是该实践的成果之一，实现了零代码到全栈轻量开发的跨越。",
      tag: "Vite + React"
    },
    {
      title: "GitHub Pages 自动化部署实践",
      desc: "熟练掌握 Git 版本控制及 GitHub Actions 工作流，实现静态网页作品集的自动化构建与全球云端托管。保障多设备、全平台秒级加载和极致的自适应呈现，体现产品经理的全面工程思维。",
      tag: "GitHub CI/CD"
    }
  ],

  matcherTitle: "AI 岗位匹配度测评",
  matcherSub: "想知道碧莹与您的团队岗位匹配度如何？粘贴岗位职责 (JD)，让 AI 匹配器深度评估并生成定制报告！",
  matcherPlaceholder: "在此处粘贴您的招聘岗位职责 (Job Description)，例如：\n1. 负责用户需求调研，建立用户画像...\n2. 具备优秀的信息架构与交互设计能力，熟练掌握 Figma...\n3. 工业设计、人机交互相关专业硕士优先...",
  matcherBtn: "开始 AI 匹配分析",
  matcherDemoBtn: "使用示例 JD 测试",
  matcherScanning: [
    "正在提取岗位核心技能标签...",
    "正在检索潘碧莹的教育背景及核心项目经验...",
    "正在深度匹配小米电视项目与适老化公益项目成果...",
    "正在利用 AI 算法分析岗位匹配度百分比...",
    "正在评估优势闪光点并起草改进建议...",
    "报告生成完毕，准备呈现！"
  ],
  matcherResultTitle: "岗位匹配评估报告",
  matcherScore: "综合匹配度",
  matcherLevel: "推荐等级",
  matcherHighlights: "核心匹配亮点",
  matcherImprovements: "建议考察与可提升方向",
  matcherSummary: "匹配度总结",
  matcherRoles: "建议匹配岗位",
  matcherClose: "关闭报告",

  contactTitle: "联系我 / Contact Me",
  contactSubtitle: "对我的研究方向、项目经历或岗位合作机会感兴趣？非常欢迎您随时与我取得联系，期待能与优秀的您共同努力！",
  contactPhone: "联系电话",
  contactEmail: "电子邮箱",
  contactStatus: "求职状态",
  contactBackToTop: "返回顶部"
};

export const enTranslations: TranslationDict = {
  navHome: "About Me",
  navEducation: "Education",
  navProjects: "Projects",
  navSkills: "Skills",
  navLearning: "Learning",
  navContact: "Contact",

  heroTitle: "Hi, I'm Pan Biying",
  heroSub: "Master of Industrial Design Engineering / Service Experience Researcher",
  heroBio: "I am a postgraduate student majoring in Industrial Design Engineering at Guangdong University of Technology, focusing heavily on service experience design and user research. Combining engineering rigor with empathetic user insights, I excel at dissecting pain points, analyzing behavioral data, and transforming them into tangible product solutions. In the era of AI, I actively champion AI-driven workflows to become a product manager and user researcher with exceptional strategic depth, user empathy, and technology vision.",
  heroMotto: "Live with passion, design with absolute clarity.",
  btnResume: "Download CV (PDF)",
  btnContact: "Get in touch",
  btnMatch: "AI Job Matcher",
  btnCopyPhone: "Copy Phone Number",
  btnCopied: "Copied to clipboard",

  eduTitle: "Education Background",
  eduSchool: "Guangdong University of Technology (GDUT)",
  eduDegree: "Master of Industrial Design Engineering",
  eduPeriod: "Sept. 2025 – June 2028 (Expected)",
  eduDirection: "Research: Service Experience Design, User Experience Research, Product Planning",
  eduDescription: "Dived deep into user insights, qualitative design methodologies, human-computer interaction, and digital service architectures. Developed a systematic engineering design workflow in courses and lab research, turning user pain points into highly structured, realistic development inputs.",
  eduAward: "Honor & Award",
  eduAwardName: "Huacan Award - National First Prize (Highest Honor for Cross-strait Young Designers)",

  projTitle: "Project Experiences",
  projRole: "My Role",
  projDuties: "Core Responsibilities",
  projViewDetail: "View Details & Deliverables",
  projCollapseDetail: "Collapse Details",

  proj1Title: "Xiaomi TV Desktop System Design White Paper",
  proj1Sub: "User Behavior Analysis / Interaction Framework / TV OS Big Screen Experience",
  proj1Desc: "This user research project studied smart TV desktop interactions and remote content-browsing behaviors. Through in-depth user interviews, eye-tracking experiments, and click-stream analytics, we mapped information discovery pathways and core control patterns under home-ambient viewing setups to provide solid framework standards for Xiaomi TV OS.",
  proj1Details: [
    "Reconstructed User Behavior Matrix: Mapped television viewing flow for 5 primary household roles, discovering a 42% user bounce rate when content depth exceeded 3 levels.",
    "Streamlined Information Architecture: Redesigned the navigation grid and visual card hierarchy, suggesting multi-dimensional recommendations that saved 35% of users' selection pathways.",
    "Formulated Layout Standards: Assisted in summarizing card alignment and sizing metrics tailored for remote visual fields (2.5m - 3.5m viewing distance)."
  ],
  proj1Insights: [
    "TV desktop interfaces represent shared family emotional hotspots; interactions must be immediate, minimalist, and zero-effort.",
    "Translating rich behavioral research findings into precise digital layout metrics is the core value of a User Experience Researcher."
  ],

  proj2Title: "Shanju Public Welfare Aging-Friendly Remodeling Project",
  proj2Sub: "Guangdong Industrial Design Association Public Welfare Project / Space Renovation & Safe Movement",
  proj2Desc: "Participated in the Shanju welfare housing initiative sponsored by the Guangdong Industrial Design Association. Visited assisted elder care homes in Shunde, conducting hours of physical surveys, safety checking, and behavioral map tracking. Leveraging service pathways, personas, and experience blueprints, we delivered a comprehensive renovation report and layout blueprint to enhance seniors' quality of life safely.",
  proj2Details: [
    "Conducted Participatory Research: Logged over 40 hours of field observation and interviews to uncover 12 critical bathroom slippage, bedroom handrail, and kitchen height safety hazards.",
    "Reorganized Elderly Spatial Pathways: Re-mapped safe, optimized routines for morning wakeup, washing, and dining, eliminating redundant pathways to avoid secondary physical falls.",
    "Delivered Renovation Blueprints: Wrote an 80-page comprehensive evaluation paper proposing low-cost modular grab-bars, folding shower chairs, and accessible lighting strategies, highly praised by the association."
  ],
  proj2Insights: [
    "Aging-friendly design is not simply drilling handrails; it is the ultimate empathy for sensory decline, everyday lifestyles, and seniors' emotional dignity.",
    "An engineering master's logic ensures that empathetic design warmth is delivered with structurally sound and flawless execution."
  ],

  proj3Title: "AI-Collaborative Prototyping & Design R&D",
  proj3Sub: "AI & Code Co-Creation / Full-stack Responsive Dev / Rapid Deployment",
  proj3Desc: "Exploring deep integrations of Large Language Models (LLM) with frontend engineering under the AI era, accelerating PM ideas and user insights into live products. Handcrafting HTML/JS/React and Tailwind CSS structures to bypass heavy R&D cycles, achieving a closed-loop validation flow of 'Insights - Interactive Prototype - Production Code - Cloud Deployment'. This personal portfolio site is a key milestone of this active investigation.",
  proj3Details: [
    "Prompt Engineering Closed-Loop: Engineered structural system prompt templates for qualitative synthesis and automated PRD generation, elevating semantic sorting speed by 3x.",
    "Full-Stack Frontend Engineering: Independently authored and refined the React + Tailwind system of this portfolio, assuring smooth micro-interactions and desktop/mobile adaptability.",
    "Intelligent Matching Logic: Designed a dual-engine diagnostics matching module (Gemini AI parsing + keyword fallback filtering) on Express server, giving recruiters an interactive fit report."
  ],
  proj3Insights: [
    "In the AI era, product managers shouldn't stay on static paper wireframes. Using AI as a lever to deploy live, responsive code prototypes makes designs instantly testable.",
    "Active co-creation with AI and code shrinks the gap between user discovery and final product validation, representing the next-gen barrier for modern digital PMs."
  ],

  skillsTitle: "Professional Skills",
  skillsResearch: "User Research & Analysis",
  skillsProduct: "Product & Service Design",
  skillsDesign: "Design & Prototyping Tools",
  skillsAi: "AI & Engineering Collaboration",

  learnTitle: "Learning & Exploration",
  learnDesc: "As an AI-native Product Manager and User Researcher, I strongly believe that artificial intelligence is more than just a booster for productivity; it is a collaborative companion that lets designers iterate, wireframe, and test complex concepts at lightning speed. I am dedicated to pioneering the full-stack workflow of 'Research-Design-AI Prototyping-Code Delivery'.",
  learnItems: [
    {
      title: "AI-Augmented Requirement Clarification & Semantic Extraction",
      desc: "Engineered structural prompts with Large Language Models to summarize qualitative user interview transcriptions. Grouped semantic keywords and themes from tens of thousands of transcript words, accelerating the qualitative synthesis cycle by 3x with robust evidentiary support.",
      tag: "ChatGPT"
    },
    {
      title: "AI-Driven Concept Visualization & Moodboard Crafting",
      desc: "Crafted situational renders, user persona scenarios, and architectural moodboards in early design stages with Midjourney and Stable Diffusion. Translated abstract product requirements into highly immersive, emotionally resonant visuals that align client expectations in seconds.",
      tag: "Midjourney"
    },
    {
      title: "AI-Enabled Rapid Prototyping & Dynamic Web Delivery",
      desc: "Bridged the gap between high-fidelity design and live code. Leveraged large code-generation assistants and OpenCode to author responsive HTML, Tailwind CSS, and React apps. This portfolio itself is a living testament to that cross-disciplinary exploration.",
      tag: "Vite + React"
    },
    {
      title: "GitHub Pages & CI/CD Deployment Practice",
      desc: "Mastered Git versioning and GitHub Actions CI/CD pipelines to host and deliver responsive portfolios globally. Maintained sub-second loading performance and perfect adaptive alignment across mobile and desktop, proving full product lifecycle execution.",
      tag: "GitHub CI/CD"
    }
  ],

  matcherTitle: "AI Job Matcher Diagnostic",
  matcherSub: "Curious how well Biying fits your team's specific requirements? Paste your Job Description (JD) below to generate a detailed AI evaluation report!",
  matcherPlaceholder: "Paste your job description responsibilities and requirements here, for example:\n1. Conduct user interviews, build personas, translate insights into features...\n2. Solid skills in Figma, wireframing, and cross-functional design collaboration...\n3. Master's degree in Industrial Design, HCI, or related field is highly preferred...",
  matcherBtn: "Analyze JD with AI",
  matcherDemoBtn: "Load Demo JD",
  matcherScanning: [
    "Extracting key skill requirements from Job Description...",
    "Retrieving Pan Biying's educational credentials and core projects...",
    "Evaluating match alignment with Xiaomi TV and Shanju eldercare data...",
    "Computing weighted capability scores via AI matching frameworks...",
    "Synthesizing matching strengths and tailored growth opportunities...",
    "Analysis finalized! Preparing comprehensive scorecard report..."
  ],
  matcherResultTitle: "Job Match Assessment Report",
  matcherScore: "Matching Score",
  matcherLevel: "Relevance Level",
  matcherHighlights: "Key Matching Strengths",
  matcherImprovements: "Areas to Explore & Interview Suggestions",
  matcherSummary: "Executive Alignment Summary",
  matcherRoles: "Suggested Roles",
  matcherClose: "Close Report",

  contactTitle: "Get In Touch",
  contactSubtitle: "Interested in my service design research, project portfolios, or hiring opportunities? I would love to hear from you. Let's make something amazing together!",
  contactPhone: "Phone Call",
  contactEmail: "Email Inbox",
  contactStatus: "Career Status",
  contactBackToTop: "Back To Top"
};
